﻿using System.Windows.Controls;

namespace POS_system_myowndesign.Views
{
    public partial class ProductUserControl : UserControl
    {
        public ProductUserControl()
        {
            InitializeComponent();
        }
    }
}